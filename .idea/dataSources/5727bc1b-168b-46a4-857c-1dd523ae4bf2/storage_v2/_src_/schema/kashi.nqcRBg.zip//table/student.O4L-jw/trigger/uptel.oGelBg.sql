create trigger uptel
  before UPDATE
  on student
  for each row
BEGIN
if length(new.stel) != 11 then
signal sqlstate 'HY000'
SET message_text = '联系方式不正确！';
end if;
END;

