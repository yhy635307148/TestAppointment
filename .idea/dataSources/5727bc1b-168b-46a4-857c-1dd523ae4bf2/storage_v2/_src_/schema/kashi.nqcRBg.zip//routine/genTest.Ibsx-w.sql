create procedure genTest()
begin
declare i int default 1;
declare testid varchar (10) ;
declare teacherid varchar(10) ;
declare thiskcid varchar (10) ;
declare thiskcname varchar (10) ;
declare thiskstime datetime ;
declare place varchar(10) ;
while i<= 20 do
-- 设置tid
select tid into teacherid from teacher order by rand() limit 1;
-- 设置testid
SET testid = CONCAT('KS',CAST(i AS CHAR(10)));
-- 设置kcid
select kcid into thiskcid from 课程 order by rand() limit 1;
-- 设置kcname
select kcname into thiskcname from 课程 where kcid=thiskcid;
-- 设置time
select kstime into thiskstime from 时间 order by rand() limit 1;
-- 设置place
set place = concat('A',cast(i as char(10)));
insert into test
values
(
	testid,
	teacherid,
	thiskcid,
	thiskcname,
	thiskstime,
	place
);
	set i=i+1;
end while;
end;

