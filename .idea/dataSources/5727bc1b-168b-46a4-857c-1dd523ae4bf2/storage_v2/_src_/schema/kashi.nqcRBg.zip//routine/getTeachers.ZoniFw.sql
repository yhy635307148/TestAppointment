create procedure getTeachers()
BEGIN
DECLARE i INT DEFAULT 1;
DECLARE gonghao VARCHAR(8) ;
DECLARE xingming VARCHAR(8) ;
DECLARE suijishu INT ;
DECLARE xingbie VARCHAR(4) ;
DECLARE tel VARCHAR(11) ;
DELETE FROM teacher;
WHILE i <= 100 DO
SET gonghao = CONCAT('T',CAST( 1000 + i AS CHAR(4)));
SELECT 姓 INTO xingming FROM 姓表 ORDER BY RAND() LIMIT 1 ;
SELECT CONCAT(xingming, 名) INTO xingming FROM 名表 ORDER BY RAND() LIMIT 1 ;
SET suijishu = CAST(RAND()*10 AS SIGNED) % 2 ;
IF suijishu = 0 THEN
SET xingbie = '男';
ELSE 
SET xingbie = '女';
END IF;
SET tel = CONCAT('1303124',CAST((RAND()*8999) + 1000 AS CHAR(4)));
INSERT INTO teacher
VALUES
(
gonghao,
xingming,
xingbie,
tel
);
SET i=i+1;
END WHILE;
    END;

