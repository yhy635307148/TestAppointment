create procedure getStudents()
BEGIN
DECLARE i INT DEFAULT 1;
DECLARE xuehao VARCHAR(8) ;
DECLARE xingming VARCHAR(8) ;
declare suijishu int ;
declare xingbie varchar(4) ;
declare xibie varchar(8) ;
DECLARE banji VARCHAR(20) ;
declare tel varchar(11) ;
DELETE FROM student;
WHILE i <= 300 DO
SET xuehao = concat('S',CAST( 19000 + i AS CHAR(8)));
SELECT 姓 INTO xingming FROM 姓表 ORDER BY RAND() LIMIT 1 ;
SELECT CONCAT(xingming, 名) INTO xingming FROM 名表 ORDER BY RAND() LIMIT 1 ;
set suijishu = cast(rand()*10 as signed) % 2 ;
if suijishu = 0 then
set xingbie = '男';
else 
set xingbie = '女';
end if;
select 系名 into xibie from 系表 order by rand() limit 1 ;
SELECT CONCAT(xibie, CAST((RAND()*3) + 17 AS CHAR(2)),'0', CAST((RAND()*3) + 1 AS CHAR(1))) 
INTO banji;
SET tel = concat('1732191',CAST((rand()*8999) + 1000 AS CHAR(4)));
INSERT INTO student
VALUES
(
xuehao,
xingming,
xingbie,
banji,
xibie,
tel
);
SET i=i+1;
END WHILE;
    END;

