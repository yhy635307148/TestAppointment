create procedure getTest()
BEGIN
DECLARE i INT DEFAULT 1;
DECLARE testid VARCHAR (10) ;
DECLARE teacherid VARCHAR(10) ;
DECLARE thiskcid VARCHAR (10) ;
DECLARE thiskcname VARCHAR (10) ;
DECLARE thiskstime DATETIME ;
DECLARE place VARCHAR(10) ;
DELETE FROM test;
WHILE i<= 100 do
SELECT tid INTO teacherid FROM teacher where tid not in (SELECT tid FROM test) ORDER BY RAND() LIMIT 1;
SET testid = CONCAT('KS',CAST(i AS CHAR(10)));
SELECT kcid INTO thiskcid FROM 课程 where 序号=(i%10);
SELECT kcname INTO thiskcname FROM 课程 WHERE kcid=thiskcid;
SELECT kstime INTO thiskstime FROM 时间 where 序号=(i/10);
if i<=9 then 
select kstime INTO thiskstime FROM 时间 WHERE 序号=0;
end if;
select 地点 into place from 地点 where 序号 in(select 序号 from 课程 where kcid=thiskcid);
INSERT INTO test
VALUES
(
	testid,
	teacherid,
	thiskcid,
	thiskcname,
	thiskstime,
	place
);
	SET i=i+1;
	
END WHILE;
END;

